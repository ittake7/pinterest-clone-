import { useState } from "react";

export default function SearchBar({onSearch}){

  const [text,setText]=useState("");

  return(
    <div style={{textAlign:"center",margin:"20px"}}>
      <input
        value={text}
        onChange={(e)=>setText(e.target.value)}
        placeholder="Search images..."
      />
      <button onClick={()=>onSearch(text || "nature")}>Search</button>
    </div>
  )
}