export default function Navbar(){
  return(
    <div style={{
      padding:"15px",
      fontSize:"22px",
      fontWeight:"bold",
      borderBottom:"1px solid #ddd"
    }}>
      Lunnent
    </div>
  )
}