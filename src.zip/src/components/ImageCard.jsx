export default function ImageCard({img}){

  return(
    <div className="card">

      <img src={img?.urls?.small} alt={img?.alt_description || "image"} />

    </div>
  )
}