const gallery = document.getElementById("gallery");

let page = 1;
let loading = false;

const accessKey = "YOUR_UNSPLASH_ACCESS_KEY";

async function loadImages() {

  if (loading) return;
  loading = true;

  const res = await fetch(
    `https://api.unsplash.com/photos?page=${page}&per_page=20&client_id=${accessKey}`
  );

  const data = await res.json();

  data.forEach(photo => {

    const card = document.createElement("div");
    card.classList.add("card");

    const img = document.createElement("img");
    img.loading = "lazy";
    img.src = photo.urls.small;

    card.appendChild(img);
    gallery.appendChild(card);

  });

  page++;
  loading = false;
}

loadImages();

window.addEventListener("scroll", () => {

  if (window.innerHeight + window.scrollY >= document.body.offsetHeight - 300) {
    loadImages();
  }

});