import { useEffect, useState } from "react";
import "./styles/masonry.css";
import { fetchImages } from "./services/api";

function App() {

  const [images, setImages] = useState([]);
  const [query, setQuery] = useState("nature");
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(false);

  // 🔥 Load Images Function
  const loadImages = async (newQuery = query, newPage = page) => {

    if (loading) return;
    setLoading(true);

    const data = await fetchImages(newQuery, newPage);

    if (newPage === 1) {
      setImages(data);
    } else {
      setImages(prev => [...prev, ...data]);
    }

    setLoading(false);
  };

  // 🔹 Initial Load
  useEffect(() => {
    loadImages();
  }, []);

  // 🔹 Infinite Scroll
  useEffect(() => {
    const handleScroll = () => {
      if (
        window.innerHeight + window.scrollY >=
        document.body.offsetHeight - 300
      ) {
        const nextPage = page + 1;
        setPage(nextPage);
        loadImages(query, nextPage);
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);

  }, [page, query]);

  return (
    <div>

      {/* HEADER */}
      <div className="header">
        <div className="logo">Lunnet</div>

        <input
          type="text"
          placeholder="Search for ideas..."
          className="search"
          onChange={(e) => setQuery(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter") {
              setPage(1);
              loadImages(e.target.value, 1);
            }
          }}
        />

        <div className="profile"></div>
      </div>

      {/* GRID */}
      <div className="container">
        <div className="grid">
          {images.map((img) => (
            <div className="card" key={img.id}>
              <img src={img.urls.small} loading="lazy" />
              
              <div className="overlay">
                <button className="save-btn">Save</button>
              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
}

export default App;