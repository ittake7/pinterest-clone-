const ACCESS_KEY = process.env.REACT_APP_UNSPLASH_KEY;

export const fetchImages = async (query = "nature", page = 1) => {
  try {
    const res = await fetch(
      `https://api.unsplash.com/search/photos?page=${page}&query=${query}&per_page=20&client_id=${ACCESS_KEY}`
    );

    const data = await res.json();

    return data.results || [];
  } catch (err) {
    console.log(err);
    return [];
  }
};