import {useState,useEffect} from "react";
import {fetchImages} from "../services/api";
import ImageCard from "../components/ImageCard";
import SearchBar from "../components/SearchBar";
import "../styles/masonry.css";

export default function Home(){

const [images, setImages] = useState([]);

const loadImages = async(q="nature") => {
  const data = await fetchImages(q);
  setImages(data || []);
}

useEffect(()=>{
  loadImages();
},[]);

  return(
    <>
      <SearchBar onSearch={loadImages}/>
    <div className="grid">
      {images?.map(img => (
        <ImageCard key={img.id} img={img}/>
            ))}
    </div>
    </>
  )
}